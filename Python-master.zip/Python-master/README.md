# Python
print("Buradaki kodlar ileride yazılacak kodlar için lazım olucak ufak kodlar ve yazdığım kodların bir yerde depolanması için kodları buraya atiyorum sevgiler")
